﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.MarkupUtils;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;
using Path = System.IO.Path;

namespace QualiTestWebTestSolution.Configuration
{
    public class Base
    {
        public static IWebDriver dr = null;
        public static string br;
        public static string url;
        public static string brNm;
        public static string brVer;
        public static string appVer;
        public static WebDriverWait wt = null;
        public static IJavaScriptExecutor js = null;
        public static Actions ac = null;
        public static IAlert alert = null;
        public static Random rand = new Random();

        public static ExtentTest FeatureName;
        public static ExtentTest scenarioName;
        public static ExtentTest logg = null;
        public static ExtentReports Extent = new ExtentReports();

        public static int webdriverWaitTimeInSeconds = 10;
        public static string pth = AppDomain.CurrentDomain.BaseDirectory;
  

        public enum logTyp { Console, Info, Error, Fail, Fatal, Warn, Skip, Pass, PassRest, Stop, Ignore, Success, Logs }

        /*---Initializing webdriver object--*/
        //Objective: This method starts the browser based on BROWSER value in app.config file, also initalizes javascript, action, webdriver wait objects at once.
        public static void Browser()
        {
            br = getConfigVal("BROWSER");
            killdriver(br);
            try
            {
                if (br.Equals("CR"))
                {
                    dr = new ChromeDriver();
                }
                else if (br.Equals("IE"))
                {
                    dr = new InternetExplorerDriver();
                }
                else
                {
                    brNm = "Unknown browser";
                    LogIt("We don't support this browser: " + br, logTyp.Stop);
                }
            }
            catch (Exception e)
            {
                LogIt("Couldn't start " + br + " webdriver :exc: " + e, logTyp.Stop);
            }

            //assign driver object to javascript and action class
            js = (IJavaScriptExecutor)dr;
            ac = new Actions(dr);
            wt = new WebDriverWait(dr, TimeSpan.FromSeconds(webdriverWaitTimeInSeconds));
            LogIt("Launched: " + br + " browser", logTyp.Info);

            //Get browser name and version
            ICapabilities caps = ((RemoteWebDriver)dr).Capabilities;
            brNm = caps.GetCapability("browserName").ToString();
            brVer = caps.GetCapability("browserVersion").ToString();
        }

        //Objective: Opens provided url and also logs notes url app version
        public static void openUrl(string browserUrl)
        {
            if (dr == null) LogIt("Webdriver not initialized", logTyp.Skip);
            try
            {
                dr.Navigate().GoToUrl(browserUrl);                
                LogIt("Launching url:" + browserUrl, logTyp.Info); 
            }
            catch (Exception e)
            {
                LogIt("Couldn't load the url:exc: " + e, logTyp.Ignore);
            }
        }

        
        //Objective: Gets By object value based on ID, xpath or CSS value provided
        public static By getByLoc(string locVal)
        {
            By byLoc = null;
            if (locVal.Substring(0, 1).Equals("/"))
                byLoc = By.XPath(GetEleVal(locVal));
            else if (locVal.Substring(0, 5).Equals("<CSS>"))
                byLoc = By.CssSelector(GetEleVal(locVal).Replace("<CSS>", "").Trim());
            else
                byLoc = By.Id(GetEleVal(locVal));
            return byLoc;
        }
        //Objective: Gets Webelement object based on locator value
        public static IWebElement GetElement(string LocatorValue)
        {
            IWebElement ele = null;

            try
            {
                ele = wt.Until(ExpectedConditions.ElementIsVisible(getByLoc(LocatorValue)));
            }
            catch (Exception e)
            {
                LogIt(GetEleLbl(LocatorValue) + " not found :exc:" + e, logTyp.Fail);
            }
            return ele;
        }

        /*---Routines for sending and clearing keys on webelement--*/
        //Objective: Entering texts on Xpath/ID/CSS
        public static void typeText(string eleXP, string text)
        {
            typeTextW(GetElement(eleXP), GetEleLbl(eleXP), text);
        }
        //Objective: Entering texts on Web Element
        public static void typeTextW(IWebElement el, string lbl, string text)
        {
            try
            {
                el.SendKeys(text);
                LogIt("Typed '" + text + "' in element: " + lbl, logTyp.Info);
            }
            catch (Exception e)
            {
                try
                {
                    if (getAttributeW(el, lbl, "class").Contains("Datepicker")) { text = DateTime.ParseExact(text, "ddMMyyyy", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy"); }
                    js.ExecuteScript("arguments[0].setAttribute('value','" + text + "')", el);
                    LogIt("Could type '" + text + "' in element: " + lbl + " :using javascript:exc:" + e, logTyp.Info);
                }
                catch (Exception ex)
                {
                    LogIt("Could not type '" + text + "' in element: " + lbl + " :exc: " + ex, logTyp.Fail);
                }
            }
        }
        //Objective: Getting texts from Xpath/ID/CSS
        public static string getText(string eleXP)
        {
            return getTextW(GetElement(eleXP), GetEleLbl(eleXP));
        }
        //Objective: Getting texts from Web Element
        public static string getTextW(IWebElement el, string lbl)
        {
            string text = "";
            try
            {
                text = el.Text;
                if (text.Equals("") || text == null)
                {
                    js.ExecuteScript("arguments[0].scrollIntoView(true);", el);
                    text = (string)js.ExecuteScript("return arguments[0].innerText;", el);
                    LogIt("Got text:<" + text + "> using JS from element:exc:" + lbl, logTyp.Logs);
                }
                else
                {
                    LogIt("Got text:<" + text + "> from element: " + lbl, logTyp.Logs);
                }
            }
            catch (Exception e)
            {
                LogIt("Could not get text from element: " + lbl + " :exc: " + e, logTyp.Fail);
            }
            return text;
        }
        //Objective: Clearing texts from Xpath/ID/CSS
        public static void clearText(string eleXP)
        {
            clearTextW(GetElement(eleXP), GetEleLbl(eleXP));
        }
        //Objective: Clearing texts from Web Element
        public static void clearTextW(IWebElement el, string lbl)
        {
            try
            {
                el.Clear();
                LogIt("Cleared texts from element: " + lbl, logTyp.Info);
            }
            catch (Exception e)
            {
                try
                {
                    js.ExecuteScript("arguments[0].value = '';", el);
                    LogIt("Cleared from element: " + lbl + " using js:exc:" + e, logTyp.Info);
                }
                catch (Exception ex)
                {
                    LogIt("Could not clear text from element: " + lbl + " :exc: " + ex, logTyp.Fail);
                }
            }
        }

        /*---Routines for web element attributes--*/
        //Objective: Gets provided attribute value from given Xpath/ID/CSS
        public static string getAttribute(string eleXP, string attr)
        {
            return getAttributeW(GetElement(eleXP), GetEleLbl(eleXP), attr);
        }
        //Objective: Gets provided attribute value from given Web Element
        public static string getAttributeW(IWebElement ele, string lbl, string attr)
        {
            string attrVal = "";
            try
            {
                attrVal = ele.GetAttribute(attr);
                LogIt("Got value:[" + attrVal + "] from element: " + lbl + " for attribute: " + attr, logTyp.Logs);
            }
            catch (Exception e)
            {
                LogIt("Could not get attribute value for " + attr + " from element: " + lbl + " :exc: " + e, logTyp.Fail);
            }
            return attrVal;
        }
       
        //Objective: Clicks given Xpath/ID/CSS
        public void ClickEl(string eleXP)
        {
            ClickElW(GetElement(eleXP), GetEleLbl(eleXP));
        }
        //Objective: Clicks given web element
        public void ClickElW(IWebElement el, string lbl)
        {
            try
            {
                el.Click();
                LogIt("Clicked element: " + lbl, logTyp.Info);
            }
            catch
            {
                try
                {
                    js.ExecuteScript("arguments[0].click();", el);
                    LogIt("Clicked '" + lbl + "' using javascript", logTyp.Info);
                }
                catch
                {
                    try
                    {
                        ScrollToTop();
                        try
                        {
                            el.Click();
                            LogIt("Clicked element: " + lbl + " after scrolling up", logTyp.Info);
                        }
                        catch
                        {
                            js.ExecuteScript("arguments[0].click();", el);
                            LogIt("Clicked '" + lbl + "' after scrolling up using javascript", logTyp.Info);
                        }
                    }
                    catch
                    {
                        ScrollToBottom();
                        try
                        {
                            el.Click();
                            LogIt("Clicked element: " + lbl + " after scrolling down", logTyp.Info);
                        }
                        catch
                        {
                            JSClickW(el, lbl + " after scrolling down");
                        }
                    }
                }
            }
        }

        //Objective: Clicks given Xpath/ID/CSS using javascript
        public void JSClick(string eleXP)
        {
            JSClickW(GetElement(eleXP), GetEleLbl(eleXP));
        }
        //Objective: Clicks given web element using javascript
        public void JSClickW(IWebElement ele, string lbl)
        {
            try
            {
                js.ExecuteScript("arguments[0].click();", ele);
                LogIt("Clicked '" + lbl + "' using javascript", logTyp.Info);
            }
            catch (Exception e)
            {
                LogIt("Could not click element: " + lbl + " :exc: " + e, logTyp.Fail);
            }

        }


        /*------ Page scrolling ------*/
        //Objective: scrolls to top of page
        public static void ScrollToTop()
        {
            try
            {
                js.ExecuteScript("window.scrollTo(document.body.scrollHeight, 0)");
                LogIt("scrolled to top of the page.", logTyp.Logs);
            }
            catch (Exception e)
            {
                LogIt("Couldn't scroll to top of page :exc: " + e, logTyp.Logs);
            }
        }
        //Objective: scrolls to bottom of page
        public static void ScrollToBottom()
        {
            long scrollHeight = 0;
            do
            {
                var newScrollHeight = (long)js.ExecuteScript("window.scrollTo(0, document.body.scrollHeight); return document.body.scrollHeight;");
                if (newScrollHeight == scrollHeight)
                {
                    break;
                }
                else
                {
                    scrollHeight = newScrollHeight;
                    wait(0.4);
                }
            } while (true);
        }

        /*------- Action classes -------*/
        
        //Objective: hovers on given Xpath/ID/CSS using action class
        public void hoverOn(string hovrEl)
        {
            hoverOnW(GetElement(hovrEl), GetEleLbl(hovrEl));
        }
        //Objective: hovers on given web element using action class
        public void hoverOnW(IWebElement el, string lbl)
        {
            try
            {
                ac.MoveToElement(el).Perform();
                LogIt("Hovered on :" + lbl, logTyp.Info);
            }
            catch (Exception e)
            {
                LogIt("Could not hover on " + lbl + " :exc: " + e, logTyp.Fail);
            }
        }

        /*------ Match routines for all data types -----*/
        
        //Objective: Matches string expected and actual values, Gives warning when case is different and also when either of them contains each other but <contains> keyword will pass them
        public void Match(string act, string exp, string msg)
        {
            if (act.Trim().Equals(exp.Trim()))
            {
                msg = msg.Replace("<contains>", "");
                LogIt("PASS >> " + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Info);
            }
            else if (act.ToUpper().Trim().Equals(exp.ToUpper().Trim()))
            {
                msg = msg.Replace("<contains>", "");
                LogIt("WARNING matched ignoring  case >> " + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Warn);
            }
            else if (msg.Contains("<contains>"))
            {
                msg = msg.Replace("<contains>", "");
                if (act.Contains(exp.Trim()))
                {
                    LogIt("Matched as Actual contains Expected >> " + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Info);
                }
                else if (exp.Contains(act.Trim()))
                {
                    LogIt("Matched as Expected contains Actual >> " + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Info);
                }
                else
                {
                    LogIt("ERROR >>" + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Error);
                }
            }
            else
            {
                if (act.Contains(exp.Trim()))
                {
                    LogIt("Not matched but Actual contains Expected >> " + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Warn);
                }
                else if (exp.Contains(act.Trim()))
                {
                    LogIt("Not matched but Expected contains Actual >> " + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Warn);
                }
                else
                {
                    LogIt("ERROR >>" + msg + " >> Actual: " + act + " :: Expected: " + exp, logTyp.Error);
                }
            }
        }

        /*----- Wait methods------*/
        //Objective: Halts code till provided seconds of time
        public static void wait(double x)
        {
            LogIt("Waiting for " + x + " second/s", logTyp.Logs);
            Thread.Sleep(Convert.ToInt32(x * 1000));
        }
                

        public static string Generatestrings(int length)
        {
            string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            StringBuilder result = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                result.Append(characters[rand.Next(characters.Length)]);
            }
            return result.ToString();
        }
        //Objective: Takes snapshot immediately and stores in Debug\screenshots folder
        public static string getSnapShot()
        {
            string pth = AppDomain.CurrentDomain.BaseDirectory + "Screenshots";
            Directory.CreateDirectory(pth);
            pth = pth + "\\" + Generatestrings(10) + ".png";
            try
            {
                Screenshot screenshot = ((ITakesScreenshot)dr).GetScreenshot();
                screenshot.SaveAsFile(pth, ScreenshotImageFormat.Png);
            }
            catch (Exception e)
            {
                pth = AppDomain.CurrentDomain.BaseDirectory.Replace("bin\\Debug\\", "") + "TestResults\\noScreenshot.png";
                LogIt("No screen shot taken due to :exc: " + e, logTyp.Logs);
            }
            return pth;
        }

        //Objective: Logs messages, screenshots in report and console and also controls execution
        public static void LogIt(string logMsg, logTyp lt)
        {
            string rMsg = "→ " + Regex.Split(logMsg, ":exc:")[0];

            switch (lt)
            {
                case logTyp.Console: //Logs message on only console for debugging purpose
                    Console.WriteLine(logMsg);
                    break;
                case logTyp.Logs: //Logs message on only log file
                    LogWrite(logMsg);
                    break;
                case logTyp.Info: //Logs message on both report & console
                    if (logg != null) logg.Info(rMsg); LogWrite(logMsg);
                    break;
                case logTyp.Error: //Logs error on both report & console with screenshot on report but continues executing scenario steps
                    if (logg != null) logg.Error(MarkupHelper.CreateLabel(rMsg, ExtentColor.Pink)).AddScreenCaptureFromPath(getSnapShot()); failStep(logMsg);
                    break;
                case logTyp.Fail: //Fails the scenario, skips rest scenarios steps and logs Failure on both report & console with screenshot on report
                    if (logg != null) logg.Fail(MarkupHelper.CreateLabel("TEST FAILED: " + rMsg, ExtentColor.Red)).AddScreenCaptureFromPath(getSnapShot()); LogWrite("FAIL: " + logMsg); Assert.Fail(logMsg);
                    break;
                case logTyp.Fatal: //Fails the scenario, skips all the scenarios of current feature and logs Failure on both report & console with screenshot on report
                    if (logg != null) logg.Fatal(MarkupHelper.CreateLabel("FEATURE BLOCKED: " + rMsg, ExtentColor.Orange)).AddScreenCaptureFromPath(getSnapShot()); setProperty("StopFeature", "YES"); LogWrite("FATAL: " + logMsg); Assert.Fail(logMsg);
                    break;
                case logTyp.PassRest: //Passes the scenario, skips next steps of scenario and logs message on both report and logs
                    if (logg != null) logg.Pass(MarkupHelper.CreateLabel(rMsg, ExtentColor.Green)); LogWrite("PASS: " + logMsg + "\nRest steps have been passed based on this."); Assert.Pass();
                    break;
                case logTyp.Pass: //Passes the scenario, skips next steps of scenario and logs message on both report and console
                    if (logg != null) logg.Pass(MarkupHelper.CreateLabel(rMsg, ExtentColor.Green)); LogWrite("PASS: " + logMsg);
                    break;
                case logTyp.Warn: //Logs warning on both report and console with screenshot on report but continues executing scenario steps
                    if (logg != null) logg.Warning(MarkupHelper.CreateLabel(rMsg, ExtentColor.Amber)).AddScreenCaptureFromPath(getSnapShot()); LogWrite("WARN: " + logMsg); Assert.Warn(logMsg);
                    break;
                case logTyp.Skip: //Skips current scenario and logs message on both report & console goes to next scenario 
                    if (logg != null) logg.Skip(MarkupHelper.CreateLabel("TEST SKIPPED: " + rMsg, ExtentColor.Grey)); LogWrite("SKIPPED: " + logMsg); Assert.Inconclusive();
                    break;
                case logTyp.Ignore: //Logs warning on both report and console with screenshot on report but skips executing remaining scenario steps
                    if (logg != null) logg.Warning(MarkupHelper.CreateLabel("TEST IGNORED: " + rMsg, ExtentColor.Cyan)).AddScreenCaptureFromPath(getSnapShot()); LogWrite("IGNORED: " + logMsg); Assert.Ignore(logMsg);
                    break;
                case logTyp.Success: //Logs message on both report & console along with screenshot on report
                    if (logg != null) logg.Info(MarkupHelper.CreateLabel(rMsg, ExtentColor.Green)).AddScreenCaptureFromPath(getSnapShot()); LogWrite("SUCCESS: " + logMsg);
                    break;
                case logTyp.Stop: //Stops execution and skips all remaining tests after this is logged
                    if (logg != null) logg.Skip(MarkupHelper.CreateLabel("TEST EXECUTION STOPPED: " + rMsg, ExtentColor.Grey)); setProperty("StopExecute", "YES"); LogWrite("STOPPED: " + logMsg); Assert.Inconclusive();
                    break;
                default: // just logs warning and continues
                    if (logg != null) logg.Warning(rMsg); LogWrite("UNKNOWN LOGTYPE: " + logMsg); Assert.Warn("Undefined log type" + logMsg);
                    break;
            }
        }

        public static void LogWrite(string logMessage)
        {
            string logPath = Path.GetFullPath(Path.Combine(pth, "..\\..\\")) + "TestResults\\logs.txt";
            try
            {
                using (StreamWriter w = File.AppendText(logPath))
                {
                    try
                    {
                        w.WriteLine("\n{0} :: {1}", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt"), logMessage);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Unable to log: " + ex);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to log: " + ex);
            }
        }

        public static void failStep(string msg)
        {
            try { Assert.Fail(""); }
            catch { LogWrite(msg); Console.WriteLine("ERROR: " + msg); }
        }

        public static void killdriver(string browsr)
        {
            if (browsr.Equals("IE"))
            { foreach (var proc in Process.GetProcessesByName("IEDriverServer")) { proc.Kill(); } }
            else if (browsr.Equals("CR"))
            { foreach (var proc in Process.GetProcessesByName("chromedriver")) { proc.Kill(); } }
            else if (browsr.Equals("FF"))
            { foreach (var proc in Process.GetProcessesByName("geckodriver")) { proc.Kill(); } }
            else if (browsr.Equals("EEL"))
            { foreach (var proc in Process.GetProcessesByName("MicrosoftWebDriver")) { proc.Kill(); } }
            else if (browsr.Equals("EEL"))
            { foreach (var proc in Process.GetProcessesByName("msedgedriver")) { proc.Kill(); } }
            else { }
        }


        /*-----Getting and setting config values and also property values------*/
        //Objective: Gets provided config value from appsettings
        public static string getConfigVal(string key)
        {
            string configVal = null;
            try
            {
                configVal = ConfigurationManager.AppSettings[key];
                if (configVal == null)
                    LogIt("Couldn't get '" + key + "' value from TestAutomation configuration.", logTyp.Error);
                else
                    LogIt("Got '" + key + "' value from TestAutomation configuration as: " + configVal, logTyp.Logs);
            }
            catch (Exception e) { LogIt("Couldn't get '" + key + "' value from TestAutomation configuration.:exc:" + e, logTyp.Error); }

            return configVal;
        }
        
        //Objective: Gets provided property value from TestAutomation properties
        public static string getProperty(string prop)
        {
            string pth = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..\\..\\"));
            string FileName = pth + "Properties\\Test.properties";
            string key = "NoKey"; string val = "NoValue";
            foreach (string row in File.ReadAllLines(FileName))
            {
                key = row.Split('=')[0].Trim();
                if (key.Equals(prop, StringComparison.OrdinalIgnoreCase))
                {
                    val = row.Replace(key + " = ", "").Trim();
                    break;
                }
            }
            LogIt("Got value" + val + " for Key: " + key + " from Test.properties", logTyp.Logs);
            return val.Contains('#') ? val.Split('#')[0].Trim() : val;
        }
        //Objective: Sets provided property value in TestAutomation properties
        public static void setProperty(string prop, string value)
        {
            string pth = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..\\..\\"));
            string FileName = pth + "Properties\\Test.properties";
            string key = "NoKey"; string val = "NoValue";
            foreach (string row in File.ReadAllLines(FileName))
            {
                key = row.Split('=')[0].Trim();
                if (key.Equals(prop, StringComparison.OrdinalIgnoreCase))
                {
                    val = row;
                    break;
                }
            }
            if (val.Equals("NoValue"))
                File.AppendAllText(FileName, Environment.NewLine + prop + " = " + value);
            else
                File.WriteAllText(FileName, File.ReadAllText(FileName).Replace(val, prop + " = " + value));

            LogIt("Updated " + prop + " = " + value + " in Test.properties", logTyp.Console);
        }
        //Objective: Extracts ID, xpath or CSS value from page elements variables
        public static string GetEleVal(string ele)
        {
            return ele.Contains("##") ? Regex.Split(ele, "##")[0].Trim() : ele;
        }
        //Objective: Extracts labels from page elements variables
        public static string GetEleLbl(string ele)
        {
            return ele.Contains("##") ? Regex.Split(ele, "##")[1].Trim() : ele;
        }

    }
}
