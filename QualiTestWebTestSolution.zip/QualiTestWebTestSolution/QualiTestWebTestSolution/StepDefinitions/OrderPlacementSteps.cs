﻿using OpenQA.Selenium;
using QualiTestWebTestSolution.Configuration;
using QualiTestWebTestSolution.Locators;
using System;
using System.Linq;
using TechTalk.SpecFlow;

namespace QualiTestWebTestSolution.StepDefinitions
{
    [Binding]
    public class OrderPlacementSteps : Base
    {
        OrderPlacementLocators OP = new OrderPlacementLocators();
        public string updatedName;
        public string refNum;

        [Given(@"Launch shopping website and login")]
        public void GivenLaunchShoppingWebsiteAndLogin()
        {
            //Launch the browser, check home page title
            openUrl(getConfigVal("WEBSITE"));
            Match(dr.Title, "My Store", "Match page title");
            //Login to website.
            if (GetElement(OP.signinbtn).Displayed)
            {
                ClickEl(OP.signinbtn);
                typeText(OP.userName, getConfigVal("EMAIL"));
                typeText(OP.passWord, getConfigVal("PASSWORD"));
                ClickEl(OP.signIn);
            }
        }

        [When(@"User add the tshirt to cart and proceed to checkout from popup")]
        public void WhenUserAddTheTshirtToCartAndProceedToCheckoutFromPopup()
        {
            ClickEl(OP.tShirt);
            hoverOn(OP.hoverProduct);
            ClickEl(OP.addCart);
            ClickEl(OP.proceedCheckout);
        }

        [Then(@"Summary page appears")]
        public void ThenSummaryPageAppearss()
        {
            Match(dr.Title, "Order - My Store", "Match Summary page title");
        }

        [When(@"User Proceed to checkout from Summary page")]
        public void WhenUserProceedToCheckoutFromSummaryPage()
        {
            ClickEl(OP.summCheckout);
        }

        [Then(@"Address page appears")]
        public void ThenAddressPageAppearss()
        {
            Match(dr.Title, "Order - My Store", "Match Address page title");
        }

        [When(@"User select the deleiver address from Address page and proceed to checkout")]
        public void WhenUserSelectTheDeleiverAddressFromAddressPageAndProceedToCheckout()
        {
            ClickEl(OP.addrCheckout);

        }

        [Then(@"Validate user check the terms of service and proceed to checkout")]
        public void ThenValidateUserCheckTheTermsOfServiceAndProceedToCheckout()
        {
            Match(getText(OP.shipHeading), "SHIPPING", "Match page heading");
            wait(1);
            ClickEl(OP.terms);
            ClickEl(OP.shipCheckout);
        }

        [When(@"On payment screen select the paymenttype (.*) and complete the orders")]
        public void WhenOnPaymentScreenSelectThePaymenttypeAndCompleteTheOrders(string paymentTyp)
        {
            Match(getText(OP.paymentHeading), "PLEASE CHOOSE YOUR PAYMENT METHOD", "Match page heading");
            if (paymentTyp.Equals("PaymentbyCheck"))
                ClickEl(OP.paybyCheck);
            else
                ClickEl(OP.paybyWire);
            ClickEl(OP.confOrder);
            LogIt(getText(OP.successMsg), logTyp.Pass);
            Console.WriteLine("MEssage: " + getText(OP.successMsg));

            // Get reference num from newly placed order
            refNum = getText(OP.successMsg);
            int pFrom = refNum.LastIndexOf("- Do not forget to include your order reference ");
            int pTo = refNum.IndexOf("- An email has been sent to you with this information");

            refNum = refNum.Substring(pFrom, pTo - pFrom);
            refNum = refNum.Replace("- Do not forget to include your order reference ", "");
            refNum = refNum.Substring(0, 9);
            LogIt("Refenernce number is: " + refNum, logTyp.Pass);

        }

        [Then(@"User validate the order is visible on Order History page")]
        public void ThenUserValidateTheOrderIsVisibleOnOrderHistoryPage()
        {
            ClickEl(OP.custAcc);
            Match(getText(OP.accHeading), "MY ACCOUNT", "Match page heading");
            ClickEl(OP.orderHistory);
            Match(getText(OP.orderHistoryHeading), "ORDER HISTORY", "Match page heading");
            Match(getText(OP.firstrefNum).Trim(), refNum, "Verify reference num of newly placed order");
        }


        //Scenario 2

        [When(@"User click on My Personal Information")]
        public void WhenUserClickOnMyPersonalInformation()
        {
            ClickEl(OP.personalInfo);
        }

        [When(@"Edit (.*) and saves the changes")]
        public void WhenEditAndSavesTheChanges(string name)
        {
            //generate random num so this can be added at the end of the given name to update a unique first name
            
            updatedName = name+ Generatestrings(2);

            clearText(OP.firstName);
            typeText(OP.firstName, updatedName);
            ClickEl(OP.confPassWord);
            typeText(OP.confPassWord, getConfigVal("PASSWORD"));
            ClickEl(OP.saveBtn);
            
        }
        [Then(@"User verify updated name")]
        public void ThenUserVerifyUpdatedName()
        {
            //Go back to Personal info and verify that first name is updated
            ClickEl(OP.myAccount);
            ClickEl(OP.personalInfo);
            Match(getAttribute(OP.firstName, "value"), updatedName, "Verify updated first name");
        }
    }
}


